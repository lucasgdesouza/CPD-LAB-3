# Função para o Radix Sort MSD para ordenar strings em ordem lexicográfica
def radix_sort_msd(strings, depth=0):
    if len(strings) <= 1:
        return strings

    # Cria buckets para cada caractere ASCII e um bucket para strings mais curtas
    buckets = [[] for _ in range(256)] + [[]]
    for s in strings:
        if depth < len(s):
            buckets[ord(s[depth])].append(s)
        else:
            buckets[-1].append(s)  # bucket para strings mais curtas que a profundidade atual

    sorted_strings = []
    for bucket in buckets:
        if bucket:
            sorted_strings.extend(radix_sort_msd(bucket, depth + 1))
    
    return sorted_strings

# Função para ler palavras de um arquivo de texto
def read_words_from_file(filename):
    with open(filename, 'r') as file:
        words = file.read().split()
    return words

# Função para escrever palavras ordenadas em um arquivo de texto
def write_words_to_file(filename, words):
    with open(filename, 'w') as file:
        for word in words:
            file.write(word + "\n")

# Função para contar a frequência de palavras
def count_word_frequencies(words):
    word_counts = {}
    for word in words:
        word_counts[word] = word_counts.get(word, 0) + 1
    return word_counts

# Função para escrever contagens de palavras em um arquivo
def write_word_counts(filename, word_counts):
    with open(filename, 'w') as file:
        for word, count in sorted(word_counts.items()):
            file.write(f"{word} {count}\n")

# Função para obter as 2000 palavras mais frequentes
def get_top_2000_words(word_counts):
    # Ordena por frequência decrescente, e lexicograficamente para contagens iguais
    sorted_word_counts = sorted(word_counts.items(), key=lambda x: (-x[1], x[0]))
    return sorted_word_counts[:2000]

# Função para escrever as 2000 palavras mais frequentes em um arquivo
def write_top_words(filename, top_words):
    with open(filename, 'w') as file:
        for word, count in top_words:
            file.write(f"{word} {count}\n")

# Processamento para o arquivo Frankenstein
print("Processando Frankenstein...")
frankenstein_words = read_words_from_file('frankenstein.txt')
sorted_frankenstein = radix_sort_msd(frankenstein_words)
write_words_to_file('frankenstein_sorted.txt', sorted_frankenstein)

frankenstein_counts = count_word_frequencies(sorted_frankenstein)
write_word_counts('frankenstein_counted.txt', frankenstein_counts)

top_frankenstein = get_top_2000_words(frankenstein_counts)
write_top_words('frankenstein_ranked.txt', top_frankenstein)
print("Frankenstein processado com sucesso.")

# Processamento para o arquivo War and Peace
print("Processando War and Peace...")
war_and_peace_words = read_words_from_file('war_and_peace.txt')
sorted_war_and_peace = radix_sort_msd(war_and_peace_words)
write_words_to_file('war_and_peace_sorted.txt', sorted_war_and_peace)

war_and_peace_counts = count_word_frequencies(sorted_war_and_peace)
write_word_counts('war_and_peace_counted.txt', war_and_peace_counts)

top_war_and_peace = get_top_2000_words(war_and_peace_counts)
write_top_words('war_and_peace_ranked.txt', top_war_and_peace)
print("War and Peace processado com sucesso.")



